export default {
  // Cấu hình khác của bạn ở đây
  devtools: { enabled: true },
  modules: ["@nuxtjs/tailwindcss"],
};
