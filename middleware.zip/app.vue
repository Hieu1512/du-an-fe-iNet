<script setup>
import { NMessageProvider } from "naive-ui";
</script>

<template>
  <n-message-provider>
    <NuxtLayout> <NuxtPage></NuxtPage> </NuxtLayout
  ></n-message-provider>
</template>

<style></style>
