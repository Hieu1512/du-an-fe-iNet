<template>
  <div class="relative w-[98%] flex flex-initial mx-auto">
    <img
      src="https://mobifonehanoi.vn/medias/634/1652839097_1618902872287_m_school.jpg"
      alt=""
      class="w-[100%] h-[600px] mx-auto rounded-lg mt-1 blur-none"
    />
    <div
      class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 items-center text-center justify-center inline"
    >
      <div class="bg-[#e9e9e9bf] p-4 rounded-md flex items-center gap-2">
        <div
          class="bg-[#FFF4E5] w-12 h-12 flex items-center justify-center rounded-md"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="ionicon w-6 h-6"
            viewBox="0 0 512 512"
          >
            <path d="M432 208H288l32-192L80 304h144l-32 192z" />
          </svg>
        </div>
        <span class="text-[#5236FF] text-4xl font-bold mr-1">Học online</span>
        <span class="text-black text-4xl font-bold mr-1"
          >thật dễ cùng mSchool</span
        >
      </div>
      <div class="text-white text-3xl text-center mt-4">
        Chương trình tiên tiến - Cải thiện kỹ năng
      </div>
      <div class="mt-14">
        <button
          class="bg-[#5236FF] text-white px-5 py-3 rounded-md mr-3 text-center transition-transform transform-gpu motion-safe:hover:scale-110"
        >
          Đăng ký ngay
        </button>
        <button
          class="bg-white text-black px-5 py-3 rounded-md text-center transition-transform transform-gpu motion-safe:hover:scale-110"
        >
          Xem khóa học
        </button>
      </div>
    </div>
  </div>
</template>
