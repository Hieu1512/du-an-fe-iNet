<template>
  <div class="w-full h-full bg-[#F3F3F4]">
    <iframe class="w-full h-full" src="http://localhost:3000"></iframe>
  </div>
</template>

<script setup>
definePageMeta({
  layout: "cms",
});
</script>
