<template>
  <div class="w-full mx-auto bg-[#F3F3F4] relative z-10">
    <PagesBanner />
    <PagesThongSo />
    <PagesTsChonChungToi />
    <PagesKhoaHocNoiBat />
    <PagesGoiKhoaHocTieuBieu />
    <PagesDanhMucKhoaHoc />
    <PagesBaiVietNoiBat />
    <PagesGiangVienTieuBieu />
    <PagesHvNoiGiVeChungToi />
    <PagesDoiTacTieuBieu />
    <PagesNhanUuDaiNgay />
  </div>
</template>
<script setup></script>
