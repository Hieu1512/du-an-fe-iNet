<template>
  <p>Trang khóa học</p>
</template>
