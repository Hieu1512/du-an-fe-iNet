<template>
  <div class="w-[72%] m-auto mt-20 flex mb-12">
    <div class="w-[35%]">
      <img
        class="w-36 h-24 ml-3 mr-32 mt-4 mb-5"
        src="https://cdn.mobiedu.vn/mskill/uploads/mb3/1698306009-mschool-240x132.png"
      />

      <div class="flex items-center gap-2">
        <img
          class="w-4"
          src="https://cdn-icons-png.flaticon.com/128/2099/2099199.png"
        />
        <nuxt-link to="#" class="py-1.5 text-[#2c2934] text-base"
          >hello@mschool.com</nuxt-link
        >
      </div>
      <div class="flex items-center gap-2">
        <img
          class="w-4"
          src="https://cdn-icons-png.flaticon.com/128/483/483947.png"
        />
        <nuxt-link to="#" class="py-1.5 text-[#2c2934] text-base"
          >+0123456789</nuxt-link
        >
      </div>
      <div class="flex items-center gap-2">
        <img
          class="w-4"
          src="https://cdn-icons-png.flaticon.com/128/447/447031.png"
        />
        <nuxt-link to="#" class="py-1.5 text-[#2c2934] text-base"
          >247 Cầu Giấy, Dịch Vọng, Cầu Giấy, Hà Nội</nuxt-link
        >
      </div>
    </div>
    <div class="w-[18%]">
      <span class="py-2"><b>Khám phá</b></span>
      <div class="mt-1">
        <div class="py-1 mt-2.5">
          <nuxt-link to="#" class="text-base">Về chúng tôi</nuxt-link>
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-base text-[#2c2934]"
            >Khóa học</nuxt-link
          >
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-base text-[#2c2934]">Tin tức</nuxt-link>
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-base text-[#2c2934]">Liên hệ</nuxt-link>
        </div>
      </div>
    </div>
    <div class="w-[25%]">
      <span class="py-2"><b>Hướng dẫn</b></span>
      <div class="mt-1">
        <div class="py-1 mt-2.5">
          <nuxt-link to="#" class="text-base">Điều khoản dịch vụ</nuxt-link>
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-[#2c2934]"
            >Chính sách đổi và hoàn tiền</nuxt-link
          >
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-[#2c2934]"
            >Chính sách bảo mật</nuxt-link
          >
        </div>
        <div class="py-1">
          <nuxt-link to="#" class="text-[#2c2934]"
            >Chính sách thanh toán</nuxt-link
          >
        </div>
      </div>
    </div>
    <div class="w-[20%]">
      <span class="py-2"><b>Theo dõi chúng tôi</b></span>
      <div class="flex mt-4">
        <div class="px-2">
          <nuxt-link to="#" class="">
            <img
              class="w-8"
              src="https://cdn-icons-png.flaticon.com/128/15047/15047495.png"
              alt="Facebook"
            />
          </nuxt-link>
        </div>
        <div class="px-2">
          <nuxt-link to="#" class="">
            <img
              class="w-8"
              src="https://cdn-icons-png.flaticon.com/128/14417/14417460.png"
              alt="X"
            />
          </nuxt-link>
        </div>
        <div class="px-2">
          <nuxt-link to="#" class="">
            <img
              class="w-8"
              src="https://cdn-icons-png.flaticon.com/128/1384/1384014.png"
              alt="In"
            />
          </nuxt-link>
        </div>
        <div class="px-2">
          <nuxt-link to="#" class="">
            <img
              class="w-8"
              src="https://cdn-icons-png.flaticon.com/128/1384/1384028.png"
              alt="Youtube"
            />
          </nuxt-link>
        </div>
      </div>
    </div>
  </div>
</template>
