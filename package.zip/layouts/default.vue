<template>
  <div class="w-full">
    <Header />
    <slot />
    <Footer />
  </div>
</template>
