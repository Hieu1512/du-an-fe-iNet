<template>
  <div class="w-full">
    <CmsDefault />
    <CmsHeader />
    <div class="bg-[#F3F3F4]">
      <CmsBanner />
      <CmsThongSo />
      <CmsTsChonChungToi />
      <CmsKhoaHocNoiBat />
      <CmsGoiKhoaHocTieuBieu />
      <CmsDanhMucKhoaHoc />
      <CmsBaiVietNoiBat />
      <CmsGiangVienTieuBieu />
      <CmsHvNoiGiVeChungToi />
      <CmsDoiTacTieuBieu />
      <PagesNhanUuDaiNgay />
    </div>
    <CmsFooter />
  </div>
</template>
